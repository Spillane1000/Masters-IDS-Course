## Notice

Put your work for assignment4 in this directory. Name your report "report.pdf". So the report should be found in group-10-2022/assignment4/report.pdf. You can also use a Jupyter Notebook for the report.

## Instructions

### Project (4a2)

For the project, we worked in a Python notebook. This can be executed as usual with the accompanied requirements.txt file.

### Running 4b1

Only smaller functions in myGeneticAlgorithm.m were changed. myGeneticAlgorithm can be run as intended.

### Running 4b2

The script to run myFeatureSelectionWithGA and to obtain the resulting visualizations is featureSelectionsPlots.m. This function contains a parameter, N (first line), which dictates the number of runs of myFeatureSelectionWithGA to execute.
