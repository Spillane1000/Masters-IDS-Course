All scripts used are fairly straight forward to run.


Of course one needs the diabetes.csv file to be in the same directory as the featureselection script for it to run properly.


Otherwise the comments within the scripts as well as the report explain how everything works.