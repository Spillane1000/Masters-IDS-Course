## Notice

Put your work for assignment3 in this directory. Name your report "report.pdf". So the report should be found in group-10-2022/assignment3/report.pdf. You can also use a Jupyter Notebook for the report.

## Instructions

All scripts used are fairly straight forward to run.


Of course one needs the diabetes.csv file to be in the same directory as the featureselection script for it to run properly.


Otherwise the comments within the scripts as well as the report explain how everything works.

