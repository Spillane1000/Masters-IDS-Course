## Notice

Put your work for assignment2a in this directory. Name your report "report.pdf". So the report should be found in group-10-2022/assignment2a/report.pdf. You can also use a Jupyter Notebook for the report.

## Instructions

The code solutions can be found in the included Matlab files. They can be executed using the Matlab editor.
