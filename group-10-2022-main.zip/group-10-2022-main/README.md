# IDS repository

Welcome to your IDS repository. This is how you will be submitting your assignments. Please make sure to attend the tutorial or read the slides on Git and GitLab before you start. Branches for the assignments have been created for you, along with a .gitignore file.

Please do not create branches **from the main branch**. You can create branches from the assignment branches. Once you are done with each assignment, you must create a merge request from that respective assignment branch to the main branch. If the .gitignore file prevents you from adding a file, but you believe you need to add it (you probably shouldn't), please create an issue. You shouldn't edit this README file. 