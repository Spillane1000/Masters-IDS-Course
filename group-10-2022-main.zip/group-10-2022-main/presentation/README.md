## Notice

Put your work for presentation in this directory. Name your report "report.pdf". So the report should be found in group-10-2022/presentation/report.pdf. You can also use a Jupyter Notebook for the report.

## Instructions

*Write instructions for running your code in this README file, if any.*